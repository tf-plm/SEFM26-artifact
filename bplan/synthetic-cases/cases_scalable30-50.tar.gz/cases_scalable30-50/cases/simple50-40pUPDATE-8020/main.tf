
terraform {
  required_providers {
    myprovider = {
      source = "example/myprovider"
    }
    }
}

provider "myprovider" {}


resource "myprovider_simple" "A21" { 
    name = "A21_new"  
    depends_on = [myprovider_simple.B21]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A9" { 
    name = "A9_new"  
    depends_on = [myprovider_simple.B9]
    lifecycle { }
}


resource "myprovider_simple" "A24" { 
    name = "A24_new"  
    depends_on = [myprovider_simple.B24]
    lifecycle { }
}


resource "myprovider_simple" "B23" { 
    name = "B23"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B4" { 
    name = "B4_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B1" { 
    name = "B1"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B2" { 
    name = "B2"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "A7" { 
    name = "A7_new"  
    depends_on = [myprovider_simple.B7]
    lifecycle { }
}


resource "myprovider_simple" "B3" { 
    name = "B3"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "A6" { 
    name = "A6_new"  
    depends_on = [myprovider_simple.B6]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B14" { 
    name = "B14_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B0" { 
    name = "B0"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B5" { 
    name = "B5"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B11" { 
    name = "B11_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B6" { 
    name = "B6"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B12" { 
    name = "B12"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B22" { 
    name = "B22"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "A3" { 
    name = "A3_new"  
    depends_on = [myprovider_simple.B3]
    lifecycle { }
}


resource "myprovider_simple" "B19" { 
    name = "B19_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "A8" { 
    name = "A8_new"  
    depends_on = [myprovider_simple.B8]
    lifecycle { }
}


resource "myprovider_simple" "A19" { 
    name = "A19_new"  
    depends_on = [myprovider_simple.B19]
    lifecycle { }
}


resource "myprovider_simple" "A12" { 
    name = "A12_new"  
    depends_on = [myprovider_simple.B12]
    lifecycle { }
}


resource "myprovider_simple" "A4" { 
    name = "A4_new"  
    depends_on = [myprovider_simple.B4]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A10" { 
    name = "A10_new"  
    depends_on = [myprovider_simple.B10]
    lifecycle { }
}


resource "myprovider_simple" "B21" { 
    name = "B21_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "A0" { 
    name = "A0_new"  
    depends_on = [myprovider_simple.B0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A1" { 
    name = "A1_new"  
    depends_on = [myprovider_simple.B1]
    lifecycle { }
}


resource "myprovider_simple" "A5" { 
    name = "A5_new"  
    depends_on = [myprovider_simple.B5]
    lifecycle { }
}


resource "myprovider_simple" "A11" { 
    name = "A11_new"  
    depends_on = [myprovider_simple.B11]
    lifecycle { }
}


resource "myprovider_simple" "B10" { 
    name = "B10_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "A13" { 
    name = "A13_new"  
    depends_on = [myprovider_simple.B13]
    lifecycle { }
}


resource "myprovider_simple" "B13" { 
    name = "B13_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B20" { 
    name = "B20"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "A23" { 
    name = "A23_new"  
    depends_on = [myprovider_simple.B23]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B8" { 
    name = "B8"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "A16" { 
    name = "A16_new"  
    depends_on = [myprovider_simple.B16]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B16" { 
    name = "B16"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "A20" { 
    name = "A20_new"  
    depends_on = [myprovider_simple.B20]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A22" { 
    name = "A22_new"  
    depends_on = [myprovider_simple.B22]
    lifecycle { }
}


resource "myprovider_simple" "A18" { 
    name = "A18_new"  
    depends_on = [myprovider_simple.B18]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A2" { 
    name = "A2_new"  
    depends_on = [myprovider_simple.B2]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B24" { 
    name = "B24"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B18" { 
    name = "B18"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B15" { 
    name = "B15"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B7" { 
    name = "B7_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B9" { 
    name = "B9_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "A14" { 
    name = "A14_new"  
    depends_on = [myprovider_simple.B14]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A17" { 
    name = "A17_new"  
    depends_on = [myprovider_simple.B17]
    lifecycle { }
}


resource "myprovider_simple" "A15" { 
    name = "A15_new"  
    depends_on = [myprovider_simple.B15]
    lifecycle { }
}


resource "myprovider_simple" "B17" { 
    name = "B17"  
    depends_on = []
    lifecycle { }
}

