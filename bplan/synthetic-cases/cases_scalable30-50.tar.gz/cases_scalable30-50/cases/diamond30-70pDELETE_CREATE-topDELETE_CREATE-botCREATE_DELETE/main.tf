
terraform {
  required_providers {
    myprovider = {
      source = "example/myprovider"
    }
    }
}

provider "myprovider" {}


resource "myprovider_simple" "R1_28" { 
    name = "R1_28_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_0" { 
    name = "R1_0_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_27" { 
    name = "R1_27_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_11" { 
    name = "R1_11_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_4" { 
    name = "R1_4"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_24" { 
    name = "R1_24_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_3" { 
    name = "R1_3_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_7" { 
    name = "R1_7_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_5" { 
    name = "R1_5_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_21" { 
    name = "R1_21_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_18" { 
    name = "R1_18_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_6" { 
    name = "R1_6_new"  
    depends_on = [myprovider_simple.R2_0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "R1_2" { 
    name = "R1_2_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_22" { 
    name = "R1_22_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_16" { 
    name = "R1_16_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_26" { 
    name = "R1_26_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_14" { 
    name = "R1_14_new"  
    depends_on = [myprovider_simple.R2_0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "R1_15" { 
    name = "R1_15_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_25" { 
    name = "R1_25"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_13" { 
    name = "R1_13_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_1" { 
    name = "R1_1_new"  
    depends_on = [myprovider_simple.R2_0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "R1_9" { 
    name = "R1_9_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_12" { 
    name = "R1_12_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_23" { 
    name = "R1_23_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_29" { 
    name = "R1_29_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_17" { 
    name = "R1_17_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_10" { 
    name = "R1_10_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_8" { 
    name = "R1_8_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_20" { 
    name = "R1_20_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R2_0" { 
    name = "R2_0_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "R1_19" { 
    name = "R1_19_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R0_0" { 
    name = "R0_0_new"  
    depends_on = [myprovider_simple.R1_18, myprovider_simple.R1_0, myprovider_simple.R1_1, myprovider_simple.R1_2, myprovider_simple.R1_3, myprovider_simple.R1_4, myprovider_simple.R1_5, myprovider_simple.R1_6, myprovider_simple.R1_7, myprovider_simple.R1_8, myprovider_simple.R1_9, myprovider_simple.R1_10, myprovider_simple.R1_11, myprovider_simple.R1_12, myprovider_simple.R1_13, myprovider_simple.R1_14, myprovider_simple.R1_15, myprovider_simple.R1_16, myprovider_simple.R1_17, myprovider_simple.R1_19, myprovider_simple.R1_20, myprovider_simple.R1_21, myprovider_simple.R1_22, myprovider_simple.R1_23, myprovider_simple.R1_24, myprovider_simple.R1_25, myprovider_simple.R1_26, myprovider_simple.R1_27, myprovider_simple.R1_28, myprovider_simple.R1_29]
    
    lifecycle {
        create_before_destroy = true
    }

}

