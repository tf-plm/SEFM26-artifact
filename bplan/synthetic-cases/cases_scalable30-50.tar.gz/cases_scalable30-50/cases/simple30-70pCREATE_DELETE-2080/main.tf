
terraform {
  required_providers {
    myprovider = {
      source = "example/myprovider"
    }
    }
}

provider "myprovider" {}


resource "myprovider_simple" "A9" { 
    name = "A9"  
    depends_on = [myprovider_simple.B9]
    lifecycle { }
}


resource "myprovider_simple" "B4" { 
    name = "B4_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B1" { 
    name = "B1_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B2" { 
    name = "B2_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A7" { 
    name = "A7_new"  
    depends_on = [myprovider_simple.B7]
    lifecycle { }
}


resource "myprovider_simple" "B3" { 
    name = "B3_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "A6" { 
    name = "A6"  
    depends_on = [myprovider_simple.B6]
    lifecycle { }
}


resource "myprovider_simple" "B14" { 
    name = "B14_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B0" { 
    name = "B0_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B5" { 
    name = "B5_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B11" { 
    name = "B11_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B6" { 
    name = "B6_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B12" { 
    name = "B12_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "A3" { 
    name = "A3"  
    depends_on = [myprovider_simple.B3]
    lifecycle { }
}


resource "myprovider_simple" "A8" { 
    name = "A8"  
    depends_on = [myprovider_simple.B8]
    lifecycle { }
}


resource "myprovider_simple" "A12" { 
    name = "A12"  
    depends_on = [myprovider_simple.B12]
    lifecycle { }
}


resource "myprovider_simple" "A4" { 
    name = "A4_new"  
    depends_on = [myprovider_simple.B4]
    lifecycle { }
}


resource "myprovider_simple" "A10" { 
    name = "A10"  
    depends_on = [myprovider_simple.B10]
    lifecycle { }
}


resource "myprovider_simple" "A0" { 
    name = "A0"  
    depends_on = [myprovider_simple.B0]
    lifecycle { }
}


resource "myprovider_simple" "A1" { 
    name = "A1_new"  
    depends_on = [myprovider_simple.B1]
    lifecycle { }
}


resource "myprovider_simple" "A5" { 
    name = "A5_new"  
    depends_on = [myprovider_simple.B5]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A11" { 
    name = "A11_new"  
    depends_on = [myprovider_simple.B11]
    lifecycle { }
}


resource "myprovider_simple" "B10" { 
    name = "B10_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "A13" { 
    name = "A13"  
    depends_on = [myprovider_simple.B13]
    lifecycle { }
}


resource "myprovider_simple" "B13" { 
    name = "B13_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B8" { 
    name = "B8_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A2" { 
    name = "A2"  
    depends_on = [myprovider_simple.B2]
    lifecycle { }
}


resource "myprovider_simple" "B7" { 
    name = "B7_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B9" { 
    name = "B9_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A14" { 
    name = "A14"  
    depends_on = [myprovider_simple.B14]
    lifecycle { }
}

