
terraform {
  required_providers {
    myprovider = {
      source = "example/myprovider"
    }
    }
}

provider "myprovider" {}


resource "myprovider_simple" "R1_0" { 
    name = "R1_0_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R35_0" { 
    name = "R35_0_new"  
    depends_on = [myprovider_simple.R36_0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "R26_0" { 
    name = "R26_0_new"  
    depends_on = [myprovider_simple.R27_0]
    lifecycle { }
}


resource "myprovider_simple" "R31_0" { 
    name = "R31_0_new"  
    depends_on = [myprovider_simple.R32_0]
    lifecycle { }
}


resource "myprovider_simple" "R38_0" { 
    name = "R38_0_new"  
    depends_on = [myprovider_simple.R39_0]
    lifecycle { }
}


resource "myprovider_simple" "R32_0" { 
    name = "R32_0_new"  
    depends_on = [myprovider_simple.R33_0]
    lifecycle { }
}


resource "myprovider_simple" "R10_0" { 
    name = "R10_0_new"  
    depends_on = [myprovider_simple.R11_0]
    lifecycle { }
}


resource "myprovider_simple" "R16_0" { 
    name = "R16_0_new"  
    depends_on = [myprovider_simple.R17_0]
    lifecycle { }
}


resource "myprovider_simple" "R19_0" { 
    name = "R19_0_new"  
    depends_on = [myprovider_simple.R20_0]
    lifecycle { }
}


resource "myprovider_simple" "R24_0" { 
    name = "R24_0_new"  
    depends_on = [myprovider_simple.R25_0]
    lifecycle { }
}


resource "myprovider_simple" "R13_0" { 
    name = "R13_0_new"  
    depends_on = [myprovider_simple.R14_0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "R14_0" { 
    name = "R14_0_new"  
    depends_on = [myprovider_simple.R15_0]
    lifecycle { }
}


resource "myprovider_simple" "R18_0" { 
    name = "R18_0_new"  
    depends_on = [myprovider_simple.R19_0]
    lifecycle { }
}


resource "myprovider_simple" "R7_0" { 
    name = "R7_0_new"  
    depends_on = [myprovider_simple.R8_0]
    lifecycle { }
}


resource "myprovider_simple" "R23_0" { 
    name = "R23_0_new"  
    depends_on = [myprovider_simple.R24_0]
    lifecycle { }
}


resource "myprovider_simple" "R6_0" { 
    name = "R6_0"  
    depends_on = [myprovider_simple.R7_0]
    lifecycle { }
}


resource "myprovider_simple" "R9_0" { 
    name = "R9_0_new"  
    depends_on = [myprovider_simple.R10_0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "R17_0" { 
    name = "R17_0"  
    depends_on = [myprovider_simple.R18_0]
    lifecycle { }
}


resource "myprovider_simple" "R29_0" { 
    name = "R29_0_new"  
    depends_on = [myprovider_simple.R30_0]
    lifecycle { }
}


resource "myprovider_simple" "R15_0" { 
    name = "R15_0_new"  
    depends_on = [myprovider_simple.R16_0]
    lifecycle { }
}


resource "myprovider_simple" "R20_0" { 
    name = "R20_0_new"  
    depends_on = [myprovider_simple.R21_0]
    lifecycle { }
}


resource "myprovider_simple" "R21_0" { 
    name = "R21_0_new"  
    depends_on = [myprovider_simple.R22_0]
    lifecycle { }
}


resource "myprovider_simple" "R22_0" { 
    name = "R22_0_new"  
    depends_on = [myprovider_simple.R23_0]
    lifecycle { }
}


resource "myprovider_simple" "R3_0" { 
    name = "R3_0"  
    depends_on = [myprovider_simple.R4_0]
    lifecycle { }
}


resource "myprovider_simple" "R34_0" { 
    name = "R34_0_new"  
    depends_on = [myprovider_simple.R35_0]
    lifecycle { }
}


resource "myprovider_simple" "R8_0" { 
    name = "R8_0_new"  
    depends_on = [myprovider_simple.R9_0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "R5_0" { 
    name = "R5_0_new"  
    depends_on = [myprovider_simple.R6_0]
    lifecycle { }
}


resource "myprovider_simple" "R36_0" { 
    name = "R36_0_new"  
    depends_on = [myprovider_simple.R37_0]
    lifecycle { }
}


resource "myprovider_simple" "R30_0" { 
    name = "R30_0_new"  
    depends_on = [myprovider_simple.R31_0]
    lifecycle { }
}


resource "myprovider_simple" "R33_0" { 
    name = "R33_0_new"  
    depends_on = [myprovider_simple.R34_0]
    lifecycle { }
}


resource "myprovider_simple" "R27_0" { 
    name = "R27_0_new"  
    depends_on = [myprovider_simple.R28_0]
    lifecycle { }
}


resource "myprovider_simple" "R4_0" { 
    name = "R4_0"  
    depends_on = [myprovider_simple.R5_0]
    lifecycle { }
}


resource "myprovider_simple" "R39_0" { 
    name = "R39_0_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "R2_0" { 
    name = "R2_0_new"  
    depends_on = [myprovider_simple.R3_0]
    lifecycle { }
}


resource "myprovider_simple" "R11_0" { 
    name = "R11_0_new"  
    depends_on = [myprovider_simple.R12_0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "R28_0" { 
    name = "R28_0_new"  
    depends_on = [myprovider_simple.R29_0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "R0_0" { 
    name = "R0_0_new"  
    depends_on = [myprovider_simple.R1_0]
    lifecycle { }
}


resource "myprovider_simple" "R12_0" { 
    name = "R12_0_new"  
    depends_on = [myprovider_simple.R13_0]
    lifecycle { }
}


resource "myprovider_simple" "R37_0" { 
    name = "R37_0"  
    depends_on = [myprovider_simple.R38_0]
    lifecycle { }
}


resource "myprovider_simple" "R25_0" { 
    name = "R25_0"  
    depends_on = [myprovider_simple.R26_0]
    lifecycle { }
}

