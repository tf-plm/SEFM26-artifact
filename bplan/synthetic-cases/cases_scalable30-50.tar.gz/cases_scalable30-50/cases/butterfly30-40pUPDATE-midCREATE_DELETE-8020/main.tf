
terraform {
  required_providers {
    myprovider = {
      source = "example/myprovider"
    }
    }
}

provider "myprovider" {}


resource "myprovider_simple" "R0_9" { 
    name = "R0_9"  
    depends_on = [myprovider_simple.R1_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_0" { 
    name = "R1_0_new"  
    depends_on = [myprovider_simple.R2_3, myprovider_simple.R2_0, myprovider_simple.R2_1, myprovider_simple.R2_2, myprovider_simple.R2_4, myprovider_simple.R2_5, myprovider_simple.R2_6, myprovider_simple.R2_7, myprovider_simple.R2_8, myprovider_simple.R2_9, myprovider_simple.R2_10, myprovider_simple.R2_11, myprovider_simple.R2_12, myprovider_simple.R2_13, myprovider_simple.R2_14]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "R0_3" { 
    name = "R0_3_new"  
    depends_on = [myprovider_simple.R1_0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "R2_9" { 
    name = "R2_9_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "R0_14" { 
    name = "R0_14_new"  
    depends_on = [myprovider_simple.R1_0]
    lifecycle { }
}


resource "myprovider_simple" "R2_14" { 
    name = "R2_14_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "R2_3" { 
    name = "R2_3_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "R0_2" { 
    name = "R0_2"  
    depends_on = [myprovider_simple.R1_0]
    lifecycle { }
}


resource "myprovider_simple" "R0_5" { 
    name = "R0_5_new"  
    depends_on = [myprovider_simple.R1_0]
    lifecycle { }
}


resource "myprovider_simple" "R0_11" { 
    name = "R0_11"  
    depends_on = [myprovider_simple.R1_0]
    lifecycle { }
}


resource "myprovider_simple" "R0_8" { 
    name = "R0_8"  
    depends_on = [myprovider_simple.R1_0]
    lifecycle { }
}


resource "myprovider_simple" "R0_1" { 
    name = "R0_1"  
    depends_on = [myprovider_simple.R1_0]
    lifecycle { }
}


resource "myprovider_simple" "R2_7" { 
    name = "R2_7_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "R0_12" { 
    name = "R0_12"  
    depends_on = [myprovider_simple.R1_0]
    lifecycle { }
}


resource "myprovider_simple" "R2_2" { 
    name = "R2_2_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "R2_6" { 
    name = "R2_6_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "R0_7" { 
    name = "R0_7_new"  
    depends_on = [myprovider_simple.R1_0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "R2_8" { 
    name = "R2_8_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "R2_1" { 
    name = "R2_1_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "R2_5" { 
    name = "R2_5_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "R2_11" { 
    name = "R2_11_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "R0_13" { 
    name = "R0_13"  
    depends_on = [myprovider_simple.R1_0]
    lifecycle { }
}


resource "myprovider_simple" "R0_10" { 
    name = "R0_10"  
    depends_on = [myprovider_simple.R1_0]
    lifecycle { }
}


resource "myprovider_simple" "R2_13" { 
    name = "R2_13_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "R0_4" { 
    name = "R0_4_new"  
    depends_on = [myprovider_simple.R1_0]
    lifecycle { }
}


resource "myprovider_simple" "R2_4" { 
    name = "R2_4_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "R2_12" { 
    name = "R2_12_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "R2_0" { 
    name = "R2_0_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "R0_0" { 
    name = "R0_0"  
    depends_on = [myprovider_simple.R1_0]
    lifecycle { }
}


resource "myprovider_simple" "R0_6" { 
    name = "R0_6"  
    depends_on = [myprovider_simple.R1_0]
    lifecycle { }
}


resource "myprovider_simple" "R2_10" { 
    name = "R2_10_new"  
    depends_on = []
    lifecycle { }
}

