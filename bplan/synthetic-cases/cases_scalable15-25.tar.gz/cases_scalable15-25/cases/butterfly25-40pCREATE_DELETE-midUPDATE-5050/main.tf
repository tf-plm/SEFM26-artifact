
terraform {
  required_providers {
    myprovider = {
      source = "example/myprovider"
    }
    }
}

provider "myprovider" {}


resource "myprovider_simple" "A0" { 
    name = "A0"  
    depends_on = [myprovider_simple.B0]
    lifecycle { }
}


resource "myprovider_simple" "C10" { 
    name = "C10_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "C8" { 
    name = "C8_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "C5" { 
    name = "C5_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A8" { 
    name = "A8_new"  
    depends_on = [myprovider_simple.B0]
    lifecycle { }
}


resource "myprovider_simple" "A5" { 
    name = "A5_new"  
    depends_on = [myprovider_simple.B0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A7" { 
    name = "A7_new"  
    depends_on = [myprovider_simple.B0]
    lifecycle { }
}


resource "myprovider_simple" "A11" { 
    name = "A11_new"  
    depends_on = [myprovider_simple.B0]
    lifecycle { }
}


resource "myprovider_simple" "A9" { 
    name = "A9_new"  
    depends_on = [myprovider_simple.B0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "C7" { 
    name = "C7"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "A2" { 
    name = "A2_new"  
    depends_on = [myprovider_simple.B0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "C6" { 
    name = "C6"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "A1" { 
    name = "A1_new"  
    depends_on = [myprovider_simple.B0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "C2" { 
    name = "C2_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "C1" { 
    name = "C1_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "C3" { 
    name = "C3_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "A10" { 
    name = "A10_new"  
    depends_on = [myprovider_simple.B0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A6" { 
    name = "A6_new"  
    depends_on = [myprovider_simple.B0]
    lifecycle { }
}


resource "myprovider_simple" "A3" { 
    name = "A3"  
    depends_on = [myprovider_simple.B0]
    lifecycle { }
}


resource "myprovider_simple" "C4" { 
    name = "C4"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B0" { 
    name = "B0_new"  
    depends_on = [myprovider_simple.C10, myprovider_simple.C0, myprovider_simple.C1, myprovider_simple.C2, myprovider_simple.C3, myprovider_simple.C4, myprovider_simple.C5, myprovider_simple.C6, myprovider_simple.C7, myprovider_simple.C8, myprovider_simple.C9, myprovider_simple.C11]
    lifecycle { }
}


resource "myprovider_simple" "A4" { 
    name = "A4_new"  
    depends_on = [myprovider_simple.B0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "C0" { 
    name = "C0_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "C11" { 
    name = "C11_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "C9" { 
    name = "C9_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}

