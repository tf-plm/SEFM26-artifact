
terraform {
  required_providers {
    myprovider = {
      source = "example/myprovider"
    }
    }
}

provider "myprovider" {}


resource "myprovider_simple" "B11" { 
    name = "B11_new"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B7" { 
    name = "B7_new"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B2" { 
    name = "B2_new"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "A0" { 
    name = "A0"  
    depends_on = [myprovider_simple.B1, myprovider_simple.B0, myprovider_simple.B2, myprovider_simple.B3, myprovider_simple.B4, myprovider_simple.B5, myprovider_simple.B6, myprovider_simple.B7, myprovider_simple.B8, myprovider_simple.B9, myprovider_simple.B10, myprovider_simple.B11, myprovider_simple.B12, myprovider_simple.B13, myprovider_simple.B14]
    lifecycle { }
}


resource "myprovider_simple" "B0" { 
    name = "B0_new"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B9" { 
    name = "B9_new"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B13" { 
    name = "B13_new"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B14" { 
    name = "B14_new"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "C0" { 
    name = "C0_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B8" { 
    name = "B8_new"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B5" { 
    name = "B5_new"  
    depends_on = [myprovider_simple.C0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B4" { 
    name = "B4_new"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B3" { 
    name = "B3_new"  
    depends_on = [myprovider_simple.C0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B6" { 
    name = "B6_new"  
    depends_on = [myprovider_simple.C0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B12" { 
    name = "B12_new"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B10" { 
    name = "B10"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B1" { 
    name = "B1_new"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}

