
terraform {
  required_providers {
    myprovider = {
      source = "example/myprovider"
    }
    }
}

provider "myprovider" {}


resource "myprovider_simple" "C5" { 
    name = "C5_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A1" { 
    name = "A1"  
    depends_on = [myprovider_simple.B0]
    lifecycle { }
}


resource "myprovider_simple" "A5" { 
    name = "A5_new"  
    depends_on = [myprovider_simple.B0]
    lifecycle { }
}


resource "myprovider_simple" "A0" { 
    name = "A0_new"  
    depends_on = [myprovider_simple.B0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B0" { 
    name = "B0_new"  
    depends_on = [myprovider_simple.C2, myprovider_simple.C0, myprovider_simple.C1, myprovider_simple.C3, myprovider_simple.C4, myprovider_simple.C5, myprovider_simple.C6]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A4" { 
    name = "A4_new"  
    depends_on = [myprovider_simple.B0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A6" { 
    name = "A6"  
    depends_on = [myprovider_simple.B0]
    lifecycle { }
}


resource "myprovider_simple" "C2" { 
    name = "C2_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "C0" { 
    name = "C0_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "C1" { 
    name = "C1_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A2" { 
    name = "A2"  
    depends_on = [myprovider_simple.B0]
    lifecycle { }
}


resource "myprovider_simple" "C3" { 
    name = "C3_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "C6" { 
    name = "C6_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A3" { 
    name = "A3"  
    depends_on = [myprovider_simple.B0]
    lifecycle { }
}


resource "myprovider_simple" "C4" { 
    name = "C4_new"  
    depends_on = []
    lifecycle { }
}

