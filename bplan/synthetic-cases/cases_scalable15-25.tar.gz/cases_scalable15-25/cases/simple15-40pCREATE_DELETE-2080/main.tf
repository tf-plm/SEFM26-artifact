
terraform {
  required_providers {
    myprovider = {
      source = "example/myprovider"
    }
    }
}

provider "myprovider" {}


resource "myprovider_simple" "A1" { 
    name = "A1"  
    depends_on = [myprovider_simple.B1]
    lifecycle { }
}


resource "myprovider_simple" "B2" { 
    name = "B2_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "A0" { 
    name = "A0_new"  
    depends_on = [myprovider_simple.B0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B0" { 
    name = "B0_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A4" { 
    name = "A4"  
    depends_on = [myprovider_simple.B4]
    lifecycle { }
}


resource "myprovider_simple" "A5" { 
    name = "A5"  
    depends_on = [myprovider_simple.B5]
    lifecycle { }
}


resource "myprovider_simple" "A6" { 
    name = "A6"  
    depends_on = [myprovider_simple.B6]
    lifecycle { }
}


resource "myprovider_simple" "B5" { 
    name = "B5_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A2" { 
    name = "A2"  
    depends_on = [myprovider_simple.B2]
    lifecycle { }
}


resource "myprovider_simple" "B4" { 
    name = "B4_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B3" { 
    name = "B3_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B6" { 
    name = "B6_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A3" { 
    name = "A3_new"  
    depends_on = [myprovider_simple.B3]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B1" { 
    name = "B1_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}

