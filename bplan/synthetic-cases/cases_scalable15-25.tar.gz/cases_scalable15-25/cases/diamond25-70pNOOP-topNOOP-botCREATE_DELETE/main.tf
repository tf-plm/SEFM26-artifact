
terraform {
  required_providers {
    myprovider = {
      source = "example/myprovider"
    }
    }
}

provider "myprovider" {}


resource "myprovider_simple" "B11" { 
    name = "B11"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B7" { 
    name = "B7_new"  
    depends_on = [myprovider_simple.C0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A0" { 
    name = "A0_new"  
    depends_on = [myprovider_simple.B18, myprovider_simple.B0, myprovider_simple.B1, myprovider_simple.B2, myprovider_simple.B3, myprovider_simple.B4, myprovider_simple.B5, myprovider_simple.B6, myprovider_simple.B7, myprovider_simple.B8, myprovider_simple.B9, myprovider_simple.B10, myprovider_simple.B11, myprovider_simple.B12, myprovider_simple.B13, myprovider_simple.B14, myprovider_simple.B15, myprovider_simple.B16, myprovider_simple.B17, myprovider_simple.B19, myprovider_simple.B20, myprovider_simple.B21, myprovider_simple.B22, myprovider_simple.B23, myprovider_simple.B24]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B13" { 
    name = "B13"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B17" { 
    name = "B17"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B4" { 
    name = "B4_new"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B18" { 
    name = "B18"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B3" { 
    name = "B3"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B20" { 
    name = "B20"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B12" { 
    name = "B12"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B19" { 
    name = "B19_new"  
    depends_on = [myprovider_simple.C0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B1" { 
    name = "B1"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B2" { 
    name = "B2_new"  
    depends_on = [myprovider_simple.C0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B16" { 
    name = "B16"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B9" { 
    name = "B9"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B15" { 
    name = "B15"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B14" { 
    name = "B14"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B5" { 
    name = "B5"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B21" { 
    name = "B21_new"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B6" { 
    name = "B6"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B10" { 
    name = "B10"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B22" { 
    name = "B22_new"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B23" { 
    name = "B23"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B0" { 
    name = "B0"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "C0" { 
    name = "C0"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B8" { 
    name = "B8"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}


resource "myprovider_simple" "B24" { 
    name = "B24"  
    depends_on = [myprovider_simple.C0]
    lifecycle { }
}

