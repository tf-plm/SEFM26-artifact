
terraform {
  required_providers {
    myprovider = {
      source = "example/myprovider"
    }
    }
}

provider "myprovider" {}


resource "myprovider_simple" "B11" { 
    name = "B11_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B7" { 
    name = "B7"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "A0" { 
    name = "A0_new"  
    depends_on = [myprovider_simple.B0]
    lifecycle { }
}


resource "myprovider_simple" "B4" { 
    name = "B4"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B3" { 
    name = "B3"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B1" { 
    name = "B1"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "A8" { 
    name = "A8_new"  
    depends_on = [myprovider_simple.B8]
    lifecycle { }
}


resource "myprovider_simple" "B2" { 
    name = "B2_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "A5" { 
    name = "A5_new"  
    depends_on = [myprovider_simple.B5]
    lifecycle { }
}


resource "myprovider_simple" "A7" { 
    name = "A7_new"  
    depends_on = [myprovider_simple.B7]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B9" { 
    name = "B9"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "A11" { 
    name = "A11_new"  
    depends_on = [myprovider_simple.B11]
    lifecycle { }
}


resource "myprovider_simple" "A9" { 
    name = "A9_new"  
    depends_on = [myprovider_simple.B9]
    lifecycle { }
}


resource "myprovider_simple" "A2" { 
    name = "A2_new"  
    depends_on = [myprovider_simple.B2]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A1" { 
    name = "A1_new"  
    depends_on = [myprovider_simple.B1]
    lifecycle { }
}


resource "myprovider_simple" "B5" { 
    name = "B5"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B6" { 
    name = "B6"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "A10" { 
    name = "A10_new"  
    depends_on = [myprovider_simple.B10]
    lifecycle { }
}


resource "myprovider_simple" "A6" { 
    name = "A6_new"  
    depends_on = [myprovider_simple.B6]
    lifecycle { }
}


resource "myprovider_simple" "A3" { 
    name = "A3_new"  
    depends_on = [myprovider_simple.B3]
    lifecycle { }
}


resource "myprovider_simple" "B10" { 
    name = "B10_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B0" { 
    name = "B0_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A4" { 
    name = "A4_new"  
    depends_on = [myprovider_simple.B4]
    lifecycle { }
}


resource "myprovider_simple" "B8" { 
    name = "B8"  
    depends_on = []
    lifecycle { }
}

