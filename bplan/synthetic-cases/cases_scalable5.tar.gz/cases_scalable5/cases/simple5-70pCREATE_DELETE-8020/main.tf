
terraform {
  required_providers {
    myprovider = {
      source = "example/myprovider"
    }
    }
}

provider "myprovider" {}


resource "myprovider_simple" "A0" { 
    name = "A0_new"  
    depends_on = [myprovider_simple.B0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "A1" { 
    name = "A1_new"  
    depends_on = [myprovider_simple.B1]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B0" { 
    name = "B0"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "B1" { 
    name = "B1_new"  
    depends_on = []
    lifecycle { }
}

