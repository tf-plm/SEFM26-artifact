
terraform {
  required_providers {
    myprovider = {
      source = "example/myprovider"
    }
    }
}

provider "myprovider" {}


resource "myprovider_simple" "R1_1" { 
    name = "R1_1_new"  
    depends_on = [myprovider_simple.R2_0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "R2_0" { 
    name = "R2_0_new"  
    depends_on = []
    lifecycle { }
}


resource "myprovider_simple" "R1_4" { 
    name = "R1_4_new"  
    depends_on = [myprovider_simple.R2_0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "R1_2" { 
    name = "R1_2_new"  
    depends_on = [myprovider_simple.R2_0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "R0_0" { 
    name = "R0_0"  
    depends_on = [myprovider_simple.R1_4, myprovider_simple.R1_0, myprovider_simple.R1_1, myprovider_simple.R1_2, myprovider_simple.R1_3]
    lifecycle { }
}


resource "myprovider_simple" "R1_0" { 
    name = "R1_0_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}


resource "myprovider_simple" "R1_3" { 
    name = "R1_3_new"  
    depends_on = [myprovider_simple.R2_0]
    lifecycle { }
}

