
terraform {
  required_providers {
    myprovider = {
      source = "example/myprovider"
    }
    }
}

provider "myprovider" {}


resource "myprovider_simple" "R4_0" { 
    name = "R4_0_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "R1_0" { 
    name = "R1_0_new"  
    depends_on = [myprovider_simple.R2_0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "R2_0" { 
    name = "R2_0_new"  
    depends_on = [myprovider_simple.R3_0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "R0_0" { 
    name = "R0_0_new"  
    depends_on = [myprovider_simple.R1_0]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "R3_0" { 
    name = "R3_0_new"  
    depends_on = [myprovider_simple.R4_0]
    
    lifecycle {
        create_before_destroy = true
    }

}

