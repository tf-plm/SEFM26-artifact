
terraform {
  required_providers {
    myprovider = {
      source = "example/myprovider"
    }
    }
}

provider "myprovider" {}


resource "myprovider_simple" "A" { 
    name = "A"  
    depends_on = [myprovider_simple.B]
    lifecycle { }
}


resource "myprovider_simple" "B" { 
    name = "B_new"  
    depends_on = []
    lifecycle { }
}

