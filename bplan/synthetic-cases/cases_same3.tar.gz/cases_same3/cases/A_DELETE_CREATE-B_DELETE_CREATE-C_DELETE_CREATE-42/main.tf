
terraform {
  required_providers {
    myprovider = {
      source = "example/myprovider"
    }
    }
}

provider "myprovider" {}


resource "myprovider_simple" "A" { 
    name = "A_new"  
    depends_on = [myprovider_simple.C]
    lifecycle { }
}


resource "myprovider_simple" "B" { 
    name = "B_new"  
    depends_on = [myprovider_simple.C]
    lifecycle { }
}


resource "myprovider_simple" "C" { 
    name = "C_new"  
    depends_on = []
    lifecycle { }
}

