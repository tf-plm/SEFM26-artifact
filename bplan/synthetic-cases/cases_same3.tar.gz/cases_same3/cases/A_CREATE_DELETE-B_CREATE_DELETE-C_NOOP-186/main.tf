
terraform {
  required_providers {
    myprovider = {
      source = "example/myprovider"
    }
    }
}

provider "myprovider" {}


resource "myprovider_simple" "A" { 
    name = "A_new"  
    depends_on = [myprovider_simple.C, myprovider_simple.B]
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "B" { 
    name = "B_new"  
    depends_on = []
    
    lifecycle {
        create_before_destroy = true
    }

}


resource "myprovider_simple" "C" { 
    name = "C"  
    depends_on = []
    lifecycle { }
}

